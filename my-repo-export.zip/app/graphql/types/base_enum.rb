module Types
  class BaseEnum < GraphQL::Schema::Enum
  end
end
