module Types
  class BaseArgument < GraphQL::Schema::Argument
  end
end
