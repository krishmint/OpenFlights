module Types
  class BaseScalar < GraphQL::Schema::Scalar
  end
end
