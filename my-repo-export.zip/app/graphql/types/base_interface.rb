module Types
  module BaseInterface
    include GraphQL::Schema::Interface
  end
end
