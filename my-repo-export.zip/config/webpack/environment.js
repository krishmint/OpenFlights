const { environment } = require('@rails/webpacker')

// Get the existing Babel loader


module.exports = environment