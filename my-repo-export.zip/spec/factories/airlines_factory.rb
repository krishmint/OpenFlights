FactoryBot.define do
  factory :airline do
    name { "Fake Airline" }
  end
end
